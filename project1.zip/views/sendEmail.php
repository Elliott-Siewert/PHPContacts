<?php 
    include("./../templates/siteHead.php");
?>

<div class="emailForm">
    <h2>Compose E-mail</h2>
    <form method="post" action="./../models/email.php">
        <label for="subject">Subject: </label>
        <input type="text" name="subject"><br>
        <label for="message">Message: </label>
        <textarea name="message" ><br>
        <input type="submit" value="Send">
    </form>
</div>

<?php include("./../templates/siteFoot.php"); ?>